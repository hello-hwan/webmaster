package com.yedam.vo;

import lombok.Data;
@Data

public class ReplyVO {
	private int replyNo;
	private String reply;
	private String replyer;
	private int boardNo;
	private String replyDate;
}
