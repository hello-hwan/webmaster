
//함수 호출 시 modal 창이 뜨도록
function modalShow(arg) {
	modalArg = arg;
	console.log('modal호출');

	let body = document.querySelector('body');
	body.className = 'modal-open';
	body.style.overflow = 'hidden';
	body.style.paddingRight = '0px';

	//modal 태그
	let modal = document.querySelector('#exampleModal');
	console.log(modal);
	modal.classList.add('show');
	modal.setAttribute('aria-modal', 'true');
	modal.setAttribute('role', 'dialog');
	modal.removeAttribute('aria-hidden');
	modal.style.display = ('block');

	let div = document.createElement('div');
	div.className = 'modal-backdrop fade show';
	console.log(div);
	body.appendChild(div);

	document.querySelector('#title').value = '';
	document.querySelector('#start').value = arg.startStr + 'T00:00:00';
	document.querySelector('#end').value = arg.endStr + 'T00:00:00';

}

function modalClose() {
	console.log('modal취소');

	let body = document.querySelector('body');
	body.className = '';
	body.style.overflow = '';

	//modal 태그
	let modal = document.querySelector('#exampleModal');
	console.log(modal);
	modal.classList.remove('show');
	modal.removeAttribute('aria-modal');
	modal.removeAttribute('role');
	modal.setAttribute('aria-hidden', 'true');
	modal.style.display = ('none');

	let div = document.querySelector('.modal-backdrop.fade.show');
	console.log(div);
	body.removeChild(div);
}