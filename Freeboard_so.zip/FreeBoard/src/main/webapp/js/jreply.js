console.log("jquery 활용 댓글 출력하기");

let page = 1;
showList(1);

function showList(page) {
	let count = page * 5 - 4;
	
	//지우고 다시 출력
	$("div.reply div.content li:not(:eq(0))").remove();
	$("ul.pagination li:not(:first):not(:last)").remove();
	
	$.ajax('replyList.do?bno=' + bno + '&page=' + page) //데이터타입 등 지정하지 않아도 자동으로 처리 가능.
		.done((result) => {
			console.log(result);
			result.forEach((item) => {

				$("<li />").append(
					$("<span />").addClass("col-sm-1").text(count),
					$("<span />").addClass("col-sm-1").text(item.replyNo),
					$("<span />").addClass("col-sm-4").text(item.reply),
					$("<span />").addClass("col-sm-1").text(item.replyer),
					$("<span />").addClass("col-sm-3").text(item.replyDate),
					$("<span />").addClass("col-sm-1").append($("<button />").text("삭제").addClass("btn btn-outline-secondary"))
				)
					.appendTo($(".reply ul"));
				
				count++;

				/*
				$(".reply span button").on("click", (e) => {
					$(e.target).closest("li").remove();
				})
				*/

			});
		})
		.fail((err) => {
			console.log(err);
		})
		.always(() => {
			console.log("replyList.do를 실행합니다.");
		});
}


//pagination
$("nav ul.pagination a").on("click", moveFunc);

function moveFunc(e) {
	e.preventDefault(); //기본이벤트(href) 차단(페이지이동 없이 값만 동적으로 가져옴)
	page = e.target.dataset.page; //데이터 담기 위해 dataset으로 가져옴
	if (page) {
		showList(page);
	}
}


//삭제 이벤트
//화면에 이미 기본적으로 존재하는 요소(감싸는 요소)에 이벤트 걸 수 있음. (ul 안에 어딜 누르든, 속한 li가 삭제되게)
$(".reply ul").on("click", "button", (e) => { //button일 때만 실행되게 할 수도 있음.
	let rno = $(e.target).parent().parent().find("span:eq(1)").text();
	console.log("rno :" + rno);

	//데이터를 url과 data옵션으로 넘겨줄 수도 있고, 직접 ?rno=rno 식으로 파라미터 넘겨줘도 됨.
	$.ajax({
		url: "removeReply.do",
		data: { rno: rno },
		method: "get", //어떤 방식으로 실행할 건지? 현재 구현기능의 경우 실행결과는 동일하긴 함.
		dataType: "json"
	}).done((result) => {
		if (result.retCode == "OK") {
			/*$(e.target).closest("li").remove();*/
			showList(page);
		} else {
			console.log(result.retCode);
		}
	}).fail((err) => {
		console.log(err);
	}).always(() => console.log("removeReply.do를 실행합니다."));
});


//추가 이벤트
$("#addReplyBtn").on("click", (e) => {
	let text = $("textarea#reply").val();
	
	if(!text){
		alert("내용을 입력해주세요.");
		return;
	}
	
	$.ajax({
		url: "addReply.do",
		data: { bno: bno,
						reply: text,
						replyer: logId },
		method: "get", //어떤 방식으로 실행할 건지? 현재 구현기능의 경우 실행결과는 동일하긴 함.
		dataType: "json"
	}).done((result) => {
		if (result.retCode == "OK") {
			$("textarea#reply").val("");
			showList(1);
		} else {
			console.log(result.retCode);
		}
	}).fail((err) => {
		console.log(err);
	}).always(() => console.log("addReply.do를 실행합니다."));
});