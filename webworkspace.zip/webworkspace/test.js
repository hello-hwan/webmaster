// test.js

let msg = 'Hello, Node.js';
console.log(msg);