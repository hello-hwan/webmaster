// js with server/declare.js

console.log(x); // var 변수는 선언되고, 값을 초기화 하지 않은경우, 강제로 메모리 할당

//var x = 5;
let x = 5; // let 변수는 초기화 안되면 메모리 공간에 할당이 안됨
console.log(x);

// var x = 7;
// let x = 7;
console.log(x);
