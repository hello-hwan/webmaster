// middleApp.js
const express = require('express');
const cors = require('cors');

const app = express();

//모든 요청에 응답
app.use(cors()); // cors에 아무런 조건을 안 두면 모든 요청에 응답한다.