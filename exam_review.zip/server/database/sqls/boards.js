
const boardList = 
`SELECT b.no
       , b.title
       , b.writer
       , b.content
       , b.created_date
       , b.updated_date
       , COUNT(c.no) as comment
FROM t_board_board b
      LEFT OUTER JOIN t_comment_board c
      ON b.no = c.no
GROUP BY b.no, b.title, b.writer, b.content, b.created_date, b.updated_date
ORDER BY no;`;

const boardInfo =
`select no
       , title
       , writer
       , content
       , created_date
       , updated_date
       , (select count(*) from t_comment_board where bno = b.no) as comment
from t_board_board b
where no = ?`;

const boardInsert =
``;

const boardUpdate =
`UPDATE t_board_board
SET ?
WHERE no = ? `;


module.exports = {
  boardList,
  boardInfo,
  boardInsert,
  boardUpdate
}