package co.yedam.mapper;

public interface ProductMapper {
	String selectMessage();
	String selectHint(String remainTimeString);

}
