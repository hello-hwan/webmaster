package co.yedam.vo;

public class ProductVO {

}
