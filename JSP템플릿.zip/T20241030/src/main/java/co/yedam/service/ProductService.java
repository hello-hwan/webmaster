package co.yedam.service;

public interface ProductService {
	String cheeringMessage();
	String hintMessage(String remainTimeString);
}
