/**
 * jreply.js
 * 
 */
console.log('start');


// jquery방식의 Ajax 호출.
$.ajax('replyList.do?bno=' + bno + '&page=1')
	.done(function(result) {
		console.log(result); //[{}, {}, ... {}]
		result.forEach((item) => {
			$('<li />').append(
				$('<span />').addClass('col-sm-2').text(item.replyNo) // 글번호.
				, $('<span />').addClass('col-sm-5').text(item.reply) // 댓글내용.
				, $('<span />').addClass('col-sm-2').text(item.replyer) // 작성자.
				, $('<span />').addClass('col-sm-2').append($('<button>삭제</button>'))// 삭제버튼.

			)
				.appendTo($('div.content ul'));
		});


	})
	.fail(function(err) {
		console.log(err);
	})

// 삭제이벤트. 따로 만들면 비동기 방식이라서 데이터베이스에서 불러오는게 더 느려서 삭제안됨
//$('div.content ul button').on('click', function(e) {
//		$(e.target).parent().parent().remove();
// 삭제이벤트. 비동기 방식용
$('div.content ul').on('click', 'button', function(e) {
	console.log($(e.target).parent().parent().find('span:eq(0)').text());
	let rno = $(e.target).parent().parent().find('span:eq(0)').text();
	$.ajax({
		url: 'removeReply.do'
		, data: { rno: rno } //{파라미터:값}
		, method: 'get'
		, dataType: 'json' //문자열 => 자바스크립트 객체로 바꿔줌 (parsing 까지 자동으로 해줌)
	})
		.done(function(result) {
			if (result.retCode == 'OK') {
				$(e.target).closest('li').remove();
			}
		})
		.fail(function(err) {
			console.log(err);
		})
	$(e.target).closest('li').remove();
})

//등록이벤트

$('#addReply').on('click', function(e) {
	let reply = $('#reply').val();
	if (!reply || !logId) {
		alert('값 입력해');
		return;
	}
	$.ajax({
		url: 'addReply.do'
		, data: { bno: bno, reply: reply, replyer: logId }
		, method: 'post'
		, dataType: 'json'
	})
		.done(function(result) {
			if (result.retCode == 'OK') {
				let item = result.retVal;
				$('<li />').append(
					$('<span />').addClass('col-sm-2').text(item.replyNo) // 글번호.
					, $('<span />').addClass('col-sm-5').text(item.reply) // 댓글내용.
					, $('<span />').addClass('col-sm-2').text(item.replyer) // 작성자.
					, $('<span />').addClass('col-sm-2').append($('<button>삭제</button>'))// 삭제버튼.

				)
					.insertAfter($('div.content ul li:eq(0)'));
			}
		})
		.fail(function(err) {
			console.log(err);
		})
})
