/**
 * data.js
 */
const data = `[{"id":1,"first_name":"Wylie","last_name":"Barsam","email":"wbarsam0@merriam-webster.com","gender":"Male","salary":3606},
{"id":2,"first_name":"Isidora","last_name":"Tarpey","email":"itarpey1@cisco.com","gender":"Female","salary":7114},
{"id":3,"first_name":"Brigham","last_name":"D'Arrigo","email":"bdarrigo2@symantec.com","gender":"Male","salary":5551},
{"id":4,"first_name":"Isis","last_name":"Yesichev","email":"iyesichev3@cpanel.net","gender":"Genderqueer","salary":6501},
{"id":5,"first_name":"Anson","last_name":"Kupis","email":"akupis4@yahoo.com","gender":"Male","salary":6574},
{"id":6,"first_name":"Arty","last_name":"Penniall","email":"apenniall5@ftc.gov","gender":"Male","salary":3065},
{"id":7,"first_name":"Kori","last_name":"Pywell","email":"kpywell6@vimeo.com","gender":"Female","salary":4425},
{"id":8,"first_name":"Sherill","last_name":"Sporgeon","email":"ssporgeon7@accuweather.com","gender":"Female","salary":9065},
{"id":9,"first_name":"Oliver","last_name":"Evetts","email":"oevetts8@ycombinator.com","gender":"Male","salary":6722},
{"id":10,"first_name":"Everett","last_name":"Levins","email":"elevins9@umich.edu","gender":"Male","salary":3897},
{"id":11,"first_name":"Giraldo","last_name":"Topaz","email":"gtopaza@histats.com","gender":"Male","salary":7279},
{"id":12,"first_name":"Yehudi","last_name":"Barkworth","email":"ybarkworthb@sourceforge.net","gender":"Male","salary":4684},
{"id":13,"first_name":"Nathanael","last_name":"Pacey","email":"npaceyc@myspace.com","gender":"Male","salary":5287},
{"id":14,"first_name":"Obie","last_name":"Cholomin","email":"ocholomind@hp.com","gender":"Male","salary":8762},
{"id":15,"first_name":"Kienan","last_name":"Vedenisov","email":"kvedenisove@stumbleupon.com","gender":"Male","salary":6357},
{"id":16,"first_name":"Ki","last_name":"Revening","email":"kreveningf@cbslocal.com","gender":"Female","salary":5340},
{"id":17,"first_name":"Cassy","last_name":"Sangwin","email":"csangwing@infoseek.co.jp","gender":"Female","salary":9842},
{"id":18,"first_name":"Myca","last_name":"Eeles","email":"meelesh@taobao.com","gender":"Male","salary":3174},
{"id":19,"first_name":"Donavon","last_name":"Bunston","email":"dbunstoni@yahoo.com","gender":"Male","salary":4601},
{"id":20,"first_name":"Ariella","last_name":"Girod","email":"agirodj@spiegel.de","gender":"Female","salary":6587}]`;