
//전체 조회
const userList = 
`select user_no
        , user_id
        , user_pwd
        , user_name
        , user_gender
        , user_age
        , join_date
 from t_users
 order by user_no
`;

//단건 조회
const userInfo = 
`select user_no
        , user_id
        , user_pwd
        , user_name
        , user_gender
        , user_age
        , join_date
 from t_users
 where user_no = ?
`;

//등록
const userInsert =
`insert into t_users
 set ?
 `;

/*
{
  "user_id" : "user02",
  "user_pwd" : "01",
  "user_name" : "user01",
  "user_gender" : "M",
  "user_age" : "10",
  "join_date" :"2024-11-15"
}
*/

//수정
const userUpdate =
`update t_users
 set ?
 where user_no =?
 `;

//삭제
const userDelete = 
`delete from t_users
 where user_no = ?
`;

module.exports={
    userList,
    userInfo,
    userInsert,
    userUpdate,
    userDelete
};


/*
create table t_users(
        user_no INT AUTO_INCREMENT PRIMARY KEY
        , user_id varchar(100) not null
        , user_pwd varchar(100) not null
        , user_name varchar(100) not null
        , user_gender char(1) check(user_gender in ('M', 'F'))
        , user_age int
        , join_date date
);
*/

