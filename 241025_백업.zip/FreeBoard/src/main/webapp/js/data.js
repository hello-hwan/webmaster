/**
 * data.js
 */
//제이슨 백틱으로 만들것
const data = `[{"id":1,"first_name":"Dunn","last_name":"Alliot","email":"dalliot0@yelp.com","gender":"Male","salary":6737},
{"id":2,"first_name":"Danielle","last_name":"Trenear","email":"dtrenear1@dailymotion.com","gender":"Female","salary":6923},
{"id":3,"first_name":"Linn","last_name":"Matts","email":"lmatts2@scribd.com","gender":"Male","salary":9666},
{"id":4,"first_name":"Harlin","last_name":"De Ambrosi","email":"hdeambrosi3@wikia.com","gender":"Male","salary":9222},
{"id":5,"first_name":"Read","last_name":"Dunsire","email":"rdunsire4@odnoklassniki.ru","gender":"Male","salary":9490},
{"id":6,"first_name":"Ewart","last_name":"Bindon","email":"ebindon5@newyorker.com","gender":"Male","salary":3860},
{"id":7,"first_name":"Alexandre","last_name":"Lavalle","email":"alavalle6@tamu.edu","gender":"Male","salary":8541},
{"id":8,"first_name":"Kaye","last_name":"Surman","email":"ksurman7@hao123.com","gender":"Female","salary":3239},
{"id":9,"first_name":"Art","last_name":"Vanacci","email":"avanacci8@ocn.ne.jp","gender":"Male","salary":7489},
{"id":10,"first_name":"Glenna","last_name":"Cahn","email":"gcahn9@foxnews.com","gender":"Female","salary":4362},
{"id":11,"first_name":"Reyna","last_name":"Searson","email":"rsearsona@mit.edu","gender":"Female","salary":7165},
{"id":12,"first_name":"Shelba","last_name":"Windram","email":"swindramb@vimeo.com","gender":"Bigender","salary":3242},
{"id":13,"first_name":"Onofredo","last_name":"Hovel","email":"ohovelc@mayoclinic.com","gender":"Male","salary":7750},
{"id":14,"first_name":"Magdaia","last_name":"Penddreth","email":"mpenddrethd@chicagotribune.com","gender":"Female","salary":8191},
{"id":15,"first_name":"Ahmad","last_name":"Sheard","email":"ashearde@google.pl","gender":"Male","salary":5164},
{"id":16,"first_name":"Randie","last_name":"Hazelhurst","email":"rhazelhurstf@studiopress.com","gender":"Male","salary":4288},
{"id":17,"first_name":"Rockwell","last_name":"Pirot","email":"rpirotg@nhs.uk","gender":"Male","salary":9180},
{"id":18,"first_name":"Whitaker","last_name":"Fishbourne","email":"wfishbourneh@alexa.com","gender":"Genderfluid","salary":7164},
{"id":19,"first_name":"Iggy","last_name":"Glawsop","email":"iglawsopi@umn.edu","gender":"Bigender","salary":8692},
{"id":20,"first_name":"Reid","last_name":"Sprigg","email":"rspriggj@cpanel.net","gender":"Male","salary":3105}]`;