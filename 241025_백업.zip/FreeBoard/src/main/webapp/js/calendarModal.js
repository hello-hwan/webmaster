/**
 * calendarModal.js
 */

function modalShow(arg) {
	modalArg = arg; // 여러 함수에서 사용할 용도.
	//body태그
	let body = document.querySelector('body');
	body.className = 'modal-open';
	body.style.overflow = 'hidden';
	body.style.paddingRight = '16px';

	let div = document.createElement('div');
	div.className = 'modal-backdrop fade show';

	body.appendChild(div);

	//modal 태그;.
	let modal = document.querySelector('#exampleModal');
	modal.classList.add('show');
	modal.setAttribute('aria-modal', true);
	modal.setAttribute('role', 'dialog');
	modal.removeAttribute('aria-hidden');
	body.style.display = 'block';

	start.value = modalArg.startStr;
	end.value = modalArg.endStr;
}

function modalHide() {
	// body 속성.
	// div 속성.
	// back-drop 속성.
}


function modalSave() {
	//title, startStr, endStr
	//fetch로 add 하는 기능 가져와서 붙여넣기 ~catch(){}까지
	let title = document.querySelector("title").value;
	let startStr = "";
	let endStr = "";

	fetch('addEvent.do?job=add&title=' + title + '&start_date=' + startStr + '&end_date=' + endStr)
		.then(resolve => resolve.json())
		.then(result => {
			if (result.retCode == "OK") {
				calendar.addEvent({
					title: title,
					start: modalArg.start,
					end: modalArg.end,
					allDay: modalArg.allDay
				})
			} else if (result.retCode == "FAIL") {
				alert("등록에러");
			}
			//eventData = result;
		})
		.catch(err => console.log(err))

}

function startChange(event){
	console.log(event);
	modalArg.start = new Date( event.target.value ); //2024-10-21
	
}


